# depth of market beta 1.1.2

指标名称：**depth of market beta**。DLL：**DepthOfMarketBeta.dll**。版本：**1.1.2**，程序集版本：**1.1.2.0**。

1.1.2 修复 ATAS beta 8.0.16 的设置序列化兼容性：原生 DOM 的 `DepthChangesFilter` 已由 `Filter` 改为 `VolumeFilter`，隐藏的同名属性也必须匹配，否则 DLL 虽可加载，读取/保存设置时仍会抛出 MissingMethodException。ATAS 包针对本机 8.0.16.275；ATASX 包针对本机 8.0.15.640，仍使用旧接口。两包不能混用。手动编译旧 SDK 时传入 `-p:LegacyDomFilter=true`。

Z1盘口状态分别显示缺少买卖盘、报价交叉、实际价差超限或数据未更新，并列出买一卖一、价差门槛和更新时间。真实盘口更新后，内部报价异常时会限频核对平台快照；仅使用完整且价差合格的快照重建基线，不把快照计成增挂。数据超时和实际宽价差仍暂停生成。

黄线说明固定在图表右侧边栏左边，文字右对齐，默认间距12像素。横向拖动时间轴不会改变说明的右边界；纵向仍随黄线价格移动。黑底按文字收紧，超过最大宽度显示省略号；重叠或空间不足时省略，不改变对应价位。

## 安装

普通ATAS使用 `ATAS/DepthOfMarketBeta.dll`，ATAS X使用 `ATASX/DepthOfMarketBeta.dll`。放入各自的自定义指标目录，重启平台，搜索并添加 **depth of market beta**。普通ATAS常见目录为 `%APPDATA%\ATAS\Indicators`。

## 设置

- Z1：开启密集区功能，默认关闭。
- Z4 → 说明距盘口栏（像素）：距图表右侧边界的间距，默认12。
- Z4 → 区域说明最大宽度：默认380，实际黑底按文字宽度收紧。
- Z4 → 最多区域短说明：默认4，空间不足或重叠时省略。

默认DOM宽度100，Net距离150，Both距离300；仅堆叠和仅拉取默认关闭；Net/Both增加青绿、减少红色。旧模板保留已保存参数。

完整安装、参数、逻辑和排查方法见 [使用说明](使用说明.md)。

## 编译

需要Windows、.NET 10 SDK和对应平台SDK，在仓库中执行 `./DepthOfMarketBeta/Build.ps1`。构建不自动安装，不启动或控制ATAS界面。
